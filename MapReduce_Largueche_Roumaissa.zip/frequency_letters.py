
import collections

# -----------------------------
# --- 1. Mapper  --------------
# -----------------------------

#process the text and outputs couples (lettre,1)for each step in string
def mapp(text_input):
   # Ensure the input is text
    text = str(text_input) 
    for char in text:
        lower_char = char.lower()  #all lettres in lowercase  from a to z     
        if 'a' <= lower_char <= 'z':
            yield (lower_char, 1)   # 'yield' means 'emit' in  MapReduce.
# -----------------------------
# --- 2 Reducer  --------------
# -----------------------------

# reduce all repetitive letters for the sme key
def reduce(letter, list_of_ones):
   #agregate all  the occurrences  in the list to get the total occurrence.
    total_frequency = sum(list_of_ones)    
    return (letter, total_frequency) #for each letter return the frequency


def run_mapreduce(text_data):
    
    print("--- starting Map phase ---")
    intermediate_data = []
    for pair in mapp(text_data):
        intermediate_data.append(pair)
    print(f"Map produces  {len(intermediate_data)} pairs.")
    

    print("--- starting Shuffle and Sort---")
    grouped_data = collections.defaultdict(list)
    for letter, count in intermediate_data:
        grouped_data[letter].append(count)
    print(f"data are composed by {len(grouped_data)} letters.")
    

    print("--- starting Reduce phase ---")
    final_results = {}
    
    for letter, list_of_ones in grouped_data.items():
        final_pair = reduce(letter, list_of_ones)   
        final_results[final_pair[0]] = final_pair[1] 
    return final_results

# ---------------------------------------------
# --- Implementation User Input Section ---
# ---------------------------------------------

input_text = input("\nPlease enter the sentence or text whose letter frequency you want to count: ")

if input_text:
    frequency_counts = run_mapreduce(input_text)
    
    print("\n--- the result of letters frequency is: ---")
    for letter, count in sorted(frequency_counts.items()):
        print(f"'{letter}': {count}")
else:
    print("no text entered.")